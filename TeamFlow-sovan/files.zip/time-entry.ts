export interface TimeEntry {
  id: number;
  taskId: number;
  userId: number;
  minutes: number;
  date: string; // ISO (YYYY-MM-DD)
  note: string;
}
