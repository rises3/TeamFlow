export interface Task {
  id: number;
  projectId: number;
  title: string;
  description: string;
  assigneeId: number;
  statusId: number;
  priorityId: number;
  dueDate: string; // ISO (YYYY-MM-DD)
  estimateHours: number;
  labelIds: number[];
}
