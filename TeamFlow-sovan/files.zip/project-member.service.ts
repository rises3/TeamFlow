import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { ProjectMember } from '../models/project-member';
import { API_BASE_URL } from './api-config';

export type ProjectMemberWrite = Omit<ProjectMember, 'id'>;

@Injectable({ providedIn: 'root' })
export class ProjectMemberService {
  private readonly http = inject(HttpClient);
  private readonly url = `${API_BASE_URL}/projectMembers`;

  list(params = new HttpParams()): Observable<ProjectMember[]> {
    return this.http.get<ProjectMember[]>(this.url, { params });
  }

  getById(id: number): Observable<ProjectMember> {
    return this.http.get<ProjectMember>(`${this.url}/${id}`);
  }

  create(data: ProjectMemberWrite): Observable<ProjectMember> {
    return this.http.post<ProjectMember>(this.url, data);
  }

  update(id: number, data: Partial<ProjectMemberWrite>): Observable<ProjectMember> {
    return this.http.patch<ProjectMember>(`${this.url}/${id}`, data);
  }

  remove(id: number): Observable<void> {
    return this.http.delete<unknown>(`${this.url}/${id}`).pipe(map(() => void 0));
  }
}
